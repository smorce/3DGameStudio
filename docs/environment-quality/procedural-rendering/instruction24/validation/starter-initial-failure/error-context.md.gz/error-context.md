# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: procedural-world.spec.ts >> Starter 3種は同じProcedural World Runtimeを使う
- Location: tests/e2e/procedural-world.spec.ts:5:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "procedural"
Received: "finite"
```

# Page snapshot

```yaml
- main [ref=f5e3]:
  - generic [ref=f5e4]:
    - link "Machine Studio" [ref=f5e5] [cursor=pointer]:
      - /url: "#"
      - generic [ref=f5e6]:
        - text: m
        - generic [ref=f5e7]: ▰
      - generic [ref=f5e8]:
        - text: MACHINE
        - generic [ref=f5e9]: STUDIO
    - generic [ref=f5e10]:
      - button "つくる" [ref=f5e11] [cursor=pointer]
      - button "くわしくつくる" [ref=f5e12] [cursor=pointer]
      - button "Studio" [ref=f5e13] [cursor=pointer]
    - button "保存" [active] [ref=f5e14] [cursor=pointer]
    - button "▶ あそぶ" [ref=f5e15] [cursor=pointer]
  - generic [ref=f5e16]:
    - generic "3Dビューポート" [ref=f5e17]
    - navigation "作るもの" [ref=f5e18]:
      - button "マシン" [ref=f5e19] [cursor=pointer]
      - button "ワールド" [ref=f5e20] [cursor=pointer]
      - button "コース" [ref=f5e21] [cursor=pointer]
    - generic:
      - text: YOUR NEXT GREAT IDEA
      - heading "つくって、走ろう。" [level=1]
      - paragraph: 南国の群島を読み込みました
    - generic [ref=f5e22]:
      - button "↶ 元に戻す" [ref=f5e23] [cursor=pointer]
      - button "↷ やり直す" [disabled] [ref=f5e24]
      - button "新しくつくる" [ref=f5e25] [cursor=pointer]
  - generic [ref=f5e26]:
    - generic [ref=f5e27]:
      - text: マシンをつくる
      - generic [ref=f5e29]: 11 パーツ
    - navigation "パーツをえらぶ" [ref=f5e30]:
      - button "▱ 板" [ref=f5e31] [cursor=pointer]:
        - generic [ref=f5e32]: ▱
        - text: 板
      - button "◉ タイヤ" [ref=f5e33] [cursor=pointer]:
        - generic [ref=f5e34]: ◉
        - text: タイヤ
      - button "⌁ サスペンション" [ref=f5e35] [cursor=pointer]:
        - generic [ref=f5e36]: ⌁
        - text: サスペンション
      - button "⚙ モーター" [ref=f5e37] [cursor=pointer]:
        - generic [ref=f5e38]: ⚙
        - text: モーター
      - button "➤ ジェット" [ref=f5e39] [cursor=pointer]:
        - generic [ref=f5e40]: ➤
        - text: ジェット
      - button "━ 関節" [ref=f5e41] [cursor=pointer]:
        - generic [ref=f5e42]: ━
        - text: 関節
      - button "▣ ブロック" [ref=f5e43] [cursor=pointer]:
        - generic [ref=f5e44]: ▣
        - text: ブロック
    - generic [ref=f5e45]:
      - text: くるっと見回す：ドラッグ ／ 近づく：スクロール
      - generic [ref=f5e46]: ひらめきに、限界はない。
```

# Test source

```ts
  1  | import { evidencePath } from "./fixtures";
  2  | import { test, expect } from "./fixtures";
  3  | import { mkdir } from "node:fs/promises";
  4  | 
  5  | test("Starter 3種は同じProcedural World Runtimeを使う", async ({ page }) => {
  6  |   await mkdir(evidencePath("docs/screenshots"), { recursive: true });
  7  |   for (const [label, preset, generatorVersion] of [
  8  |     ["くるま", "grassland", 1],
  9  |     ["ひこうき", "airfield", 1],
  10 |     ["ボート", "designed-world", 2],
  11 |   ] as const) {
  12 |     await page.goto("/");
  13 |     await page.evaluate(() => localStorage.clear());
  14 |     await page.reload();
  15 |     await page.getByRole("button", { name: label, exact: false }).click();
  16 |     await expect(page.getByText(/パーツ$/)).toBeVisible();
  17 |     await page.getByRole("button", { name: "保存", exact: true }).click();
  18 |     const project = await page.evaluate(() =>
  19 |       JSON.parse(localStorage.getItem("machine-studio.project") ?? "null"),
  20 |     );
  21 |     expect(project.schemaVersion).toBe(7);
> 22 |     expect(project.world.source.kind).toBe("procedural");
     |                                       ^ Error: expect(received).toBe(expected) // Object.is equality
  23 |     expect(project.world.source.preset).toBe(preset);
  24 |     expect(project.world.source.generatorVersion).toBe(generatorVersion);
  25 |     if (label === "ボート") {
  26 |       expect(project.world.source.design.islands).toHaveLength(5);
  27 |       expect(project.world.source.design.islands[0].biome).toBe("tropical");
  28 |     }
  29 |     await page.screenshot({
  30 |       path: evidencePath(`docs/screenshots/procedural-${preset}.png`),
  31 |       fullPage: true,
  32 |     });
  33 |   }
  34 | });
  35 | 
```